import '../Img/Calendar.jpg'
export let Homescreen= [
    {
id: 1,
description: "Calender",
backgroundColor: '#FBEBEE',
 "ImagePath": require('../Img/Calendar.jpg'),
imageColor: "#fff"
},

{
    id: 2,
    description: "Attendance",
    backgroundColor: '#EAEBFD',
    ImagePath : require('../Img/Attendance.jpg'),
    imageColor: "#fff"
    },

{
        id: 3,
        description: "General Insights",
        backgroundColor: '#E7F3C3',
        ImagePath: require('../Img/GeneralInsights.jpg'),
        imageColor: "#fff",

        },
     {
            id: 4,
            description: "Annoncements",
            backgroundColor: '#FEE1D1',
            ImagePath: require('../Img/Annoucement.jpg'),
            imageColor: "#fff"
            },

            {
                id: 5,
                description: "Message",
                backgroundColor: '#F1E2F7',
                ImagePath: require('../Img/Messages.jpg'),
                imageColor: "#fff"
                },
                {
                    id: 6,
                    description: "Entry/Dispersal",
                    backgroundColor: '#FFEBB9',
                    ImagePath: require('../Img/Dispersal.jpg'),
                    imageColor: "#fff"
                    }
        

] 