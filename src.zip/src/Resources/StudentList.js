export const studentlistData = [
    {
      id: 1,
      ImagePath: require('../Img/GeneralInsights.jpg'),
      FirstName: 'Aabhyuday ',
      LastName: 'Jhunjhunwala',
      attendance: null,
      attendance:[
        { 
            id:1,
            present: 'P',
            presentColor: '#00B1B1'
          },
          {
            id:2,
            absent: 'A',
            absentColor: '#FA8072',
          },
        {
            id:3,
            ExcusedAbsence: 'E',
            ExcusedAbsenceColor: '#DBDBDB',
        },
          {
            id:4,
            leave: 'L',
            leaveColor: '#FFD361'
          },
      ],
    },
    {
      id: 2,
      ImagePath: require('../Img/GeneralInsights.jpg'),
      FirstName: 'Aabhyuday ',
      LastName: 'Jhunjhunwala',
      attendance: null,
      attendance:[
        { 
            id:1,
            present: 'P',
            presentColor: '#00B1B1'
          },
          {
            id:2,
            absent: 'A',
            absentColor: '#FA8072',
          },
        {
            id:3,
            ExcusedAbsence: 'E',
            ExcusedAbsenceColor: '#DBDBDB',
        },
          {
            id:4,
            leave: 'L',
            leaveColor: '#FFD361'
          },
      ],
    },
    {
        id: 3,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
       attendance: null,
       attendance:[
        { 
            id:1,
            present: 'P',
            presentColor: '#00B1B1'
          },
          {
            id:2,
            absent: 'A',
            absentColor: '#FA8072',
          },
        {
            id:3,
            ExcusedAbsence: 'E',
            ExcusedAbsenceColor: '#DBDBDB',
        },
          {
            id:4,
            leave: 'L',
            leaveColor: '#FFD361'
          },
      ],
      },
      {
        id: 4,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 5,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 6,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 7,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 8,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 9,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 10,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 11,
        ImagePath: require('../Img/GeneralInsights.jpg'),
        FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 12,
        ImagePath: require('../Img/GeneralInsights.jpg'),
         FirstName: 'Aabhyuday ',
 LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 13,
        ImagePath: require('../Img/GeneralInsights.jpg'),
         FirstName: 'Aabhyuday ',
 LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 14,
        ImagePath: require('../Img/GeneralInsights.jpg'),
         FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 15,
        ImagePath: require('../Img/GeneralInsights.jpg'),
         FirstName: 'Aabhyuday ',
         LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 16,
        ImagePath: require('../Img/GeneralInsights.jpg'),
         FirstName: 'Aabhyuday ',
         LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 17,
        ImagePath: require('../Img/GeneralInsights.jpg'),
         FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
      {
        id: 18,
        ImagePath: require('../Img/GeneralInsights.jpg'),
         FirstName: 'Aabhyuday ',
        LastName: 'Jhunjhunwala',
        attendance: null,
        attendance:[
            { 
                id:1,
                present: 'P',
                presentColor: '#00B1B1'
              },
              {
                id:2,
                absent: 'A',
                absentColor: '#FA8072',
              },
            {
                id:3,
                ExcusedAbsence: 'E',
                ExcusedAbsenceColor: '#DBDBDB',
            },
              {
                id:4,
                leave: 'L',
                leaveColor: '#FFD361'
              },
          ],
      },
    {
      id: 19,
      ImagePath: require('../Img/GeneralInsights.jpg'),
      FirstName: 'Aabhyuday ',
      LastName: 'Jhunjhunwala',
      attendance: null,
      attendance:[
        { 
            id:1,
            present: 'P',
            presentColor: '#00B1B1'
          },
          {
            id:2,
            absent: 'A',
            absentColor: '#FA8072',
          },
        {
            id:3,
            ExcusedAbsence: 'E',
            ExcusedAbsenceColor: '#DBDBDB',
        },
          {
            id:4,
            leave: 'L',
            leaveColor: '#FFD361'
          },
      ],
    },
  ];


