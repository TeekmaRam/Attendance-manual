import * as React from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TouchableOpacity,
  Image
} from 'react-native';
import { studentlistData } from '../../../Resources/StudentList'
import Icon from 'react-native-vector-icons/AntDesign';
import Bell from 'react-native-vector-icons/Fontisto'

Icon.loadFont();

function Attendance(props)  {

const [selectedAttendance, setSelectedAttendance] = React.useState(studentlistData)
const [StudentList, setStudentList] = React.useState(studentlistData);


React.useEffect(() => {
  // setStudentList(studentlistData)
},[])

const OnSelectAttendance = (attendanceItem, item) => {
  attendanceItem.backgroundColor = true
attendanceItem.EditIcon = true;
let updatedStudentList = StudentList.map((Attendan) => {
  if (Attendan.id === item.id) {
    return{
      ...Attendan,
          attendance: [
            attendanceItem
          ],
    }
  }
  return Attendan;
})
setStudentList(updatedStudentList);

}


const AttendanceEditbutton = (attendanceItem, item) => {
 console.log(attendanceItem.id  !== 4)

if (attendanceItem.id !== 1) {
  delete attendanceItem.backgroundColor;
} 
if (attendanceItem.id !== 2) {
  delete attendanceItem.backgroundColor;
} 
if (attendanceItem.id !== 3) {
  delete attendanceItem.backgroundColor;
} 
if (attendanceItem.id !== 4) {
  delete attendanceItem.backgroundColor;
} 


 delete attendanceItem.EditIcon 
let updatedStudentList = selectedAttendance.map((Attendan) => {
  if (Attendan.id === item.id) {
    console.log(Attendan)
    return{
      ...Attendan,
          attendance:Attendan.attendance,
    }
  }
  return Attendan;
})
setStudentList(updatedStudentList);
}


const Attendanceoptions = (attendanceItem, item) => {
  return(
    <View style={{flexDirection: 'row'}}>
    <TouchableOpacity onPress={() => OnSelectAttendance(attendanceItem, item)} 
    style={[ 
      attendanceItem?.EditIcon ? styles.AfterSelectedAttendance : styles.SelectedAttendance 
      ,{backgroundColor:
        attendanceItem?.present  ? attendanceItem.backgroundColor ?  attendanceItem?.presentColor: null : null  ??
         attendanceItem?.absent ?  attendanceItem.backgroundColor ? attendanceItem?.absentColor: null: null  ??
         attendanceItem?.ExcusedAbsence ? attendanceItem.backgroundColor ?  attendanceItem?.ExcusedAbsenceColor: null : null ??
         attendanceItem?.leave ? attendanceItem.backgroundColor ?  attendanceItem?.leaveColor  : null : null  
      }]}
      >
      <Text style={styles.TextStyle}>
        { attendanceItem?.present ? attendanceItem?.present : null ?? 
          attendanceItem?.absent ? attendanceItem?.absent : null ?? 
          attendanceItem?.ExcusedAbsence ? attendanceItem?.ExcusedAbsence : null ?? 
          attendanceItem?.leave ? attendanceItem?.leave : null ??  ""}
          </Text>
     </TouchableOpacity>
       {attendanceItem?.EditIcon ?  
       (
        <TouchableOpacity onPress={() => AttendanceEditbutton(attendanceItem,item)} style={styles.EditButtonContainer}>
         <Image source={require('../../../Img/pen.jpg')} style={styles.EditButton} />
        </TouchableOpacity>
     ):(null) }
     </View>
  )
}


  const RenderItem = ({item}) => {
    return(
      <View key={item.id} style={styles.AttendanceListContainer}>
      <Image source={require('../../../Img/Profile.jpg')} style={styles.ProfileImage} />
      <View style={styles.UsernameStyle}>
      <Text style={styles.Firstnamestyle}>{item?.FirstName ?? ""}</Text>
      <Text style={styles.Lastnamestyle}>{item?.LastName ?? ""}</Text>
      </View>
      <View>
      <View  style={styles.AttendanceoptionListConatiner}>
         {item?.attendance?.map((attendanceItem, index) => Attendanceoptions(attendanceItem, item))}  
      </View>
      </View>
      <Image source={require('../../../Img/Notification.jpg')} style={styles.Notification} />
      </View>
    )
  }

  return (
   <View style={styles.AttentdancescreenMainContainer}> 
    <View style={styles.Profile}>
      <View style={styles.ProfileHeadlineContainer}>
      <Text style={styles.UsernameTextstyle}>Ratual Sarkar</Text>
       <View style={styles.DropdownIcon}>
      <Text style={styles.DropdownTextstyle}>Arth Hours-Dhara</Text>
      <Icon name="down" size={16} color={"#7869E6"} top={2}  marginLeft={6}/>
      </View>
      </View>
      <View style={styles.BellConatiner}> 
      <View style={styles.BellBackgeound}> 
        <Bell name='bell' size={16} color='#7869E6' />
        </View>
      </View>
    </View>
    <FlatList 
    data={StudentList ?? []}
     keyExtractor={(item) => item.id}
     renderItem={RenderItem}
    />
   </View>
  );
}

const styles = StyleSheet.create({

  AttentdancescreenMainContainer : {
    flex: 1,
    backgroundColor: 'white'
  },

  AttendanceListContainer : {
    flexDirection: 'row',
     justifyContent: 'space-around',
     marginVertical: 30
      
  },

  UsernameStyle : {
     width: 82,
     height: 32,
      marginTop:8
  },

  Firstnamestyle : {
  color: '#333333',
// fontFamily: ''
  fontWeight: '600',
  fontSize: 14,
  lineHeight: 15
  },

  Lastnamestyle : {
    color: '#777777',
    // fontFamily: ''
    fontWeight: '500',
    fontSize: 10,
    lineHeight: 15
  },

  ProfileImage : {
    height: 48,
    width: 48,
    borderRadius: 25,
  },


  AttendanceoptionListConatiner : {
    flexDirection: 'row',
  },

  SelectedAttendance : {
    width: 24,
    height: 24,
    borderColor: '#C4C4C4',
    borderWidth: 1,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:8,
    marginHorizontal: 10
   
  },

  AfterSelectedAttendance : {
    width: 24,
    height: 24,
    borderColor: '#C4C4C4',
    borderWidth: 1,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:8,
    marginHorizontal: 10,
    marginLeft: 114
  },
  TextStyle: {
    // fontFamily: ""
    fontWeight: '600',
    color: '#333333',
    fontSize: 13
  },

  EditButtonContainer : {
   marginTop: 11,
   marginLeft: 14
  },

  EditButton : {
    width: 16,
    height: 16
  },

  Notification : {
    marginTop:8,
    height: 24,
    width: 24
  }
  
});

export default Attendance;
